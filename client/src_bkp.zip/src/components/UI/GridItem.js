import { Grid } from "@mui/material";
import TextField from "@mui/material/TextField";
import InputAdornment from "@mui/material/InputAdornment";

const displayGridItems = (
  width,
  listOfTextFieldItems,
  resumeContext,
  register
) => {
  return (
    <>
      {listOfTextFieldItems.map((item) => {
        return (
          <Grid key={item.id} item xs={width}>
            <TextField
              label={item.label}
              id={item.id}
              defaultValue={resumeContext[item.id]}
              variant="filled"
              // key={item.id}
              {...register(item.id)}
              sx={{
                width: item.id !== "" ? "100%" : "215%",
                background: "#f2f2f2",
                borderRadius: "2px",
                fontFamily: "Raleway-SemiBold",
                marginTop: "5px",
                input: {
                  fontFamily: "Raleway-SemiBold",
                },
              }}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">{item.icon}</InputAdornment>
                ),
              }}
            />
          </Grid>
        );
      })}
    </>
  );
};

export default displayGridItems;
