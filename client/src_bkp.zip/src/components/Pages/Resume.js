import { React, useState } from "react";
import Education from "./Education";
import Experience from "./Experience";
import AdditionalDetails from "./AdditionalDetails";
import PersonalDetails from "./PersonalDetails";
import Projects from "./Projects";
// import Card from "../UI/Card";

const Resume = (props) => {
  const [step, setStep] = useState(1);
  const [resumeState, setResumeState] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phoneNumber: "",
    website: "",
    github: "",
    linkedIn: "",
    twitter: "",
    state: "",
    city: "",
    college: "",
    collegeStart: "",
    collegeEnd: "",
    collegeQual: "",
    collegeDesc: "",
    school: "",
    schoolStart: "",
    schoolEnd: "",
    schoolQual: "",
    schoolDesc: "",
    projectTitle1: "",
    projectLink1: "",
    projectDesc1: "",
    projectTitle2: "",
    projectLink2: "",
    projectDesc2: "",
    company1Exp: "",
    company1Pos: "",
    company1Duration: "",
    company1Desc: "",
    company2Exp: "",
    company2Pos: "",
    company2Duration: "",
    company2Desc: "",
    skill1: "",
    skill2: "",
    skill3: "",
    skill4: "",
    skill5: "",
    skill6: "",
    interest1: "",
    interest2: "",
    interest3: "",
    interest4: "",
    interest5: "",
    interest6: "",
  });
  const saveData = (data) => {
    setResumeState({ ...resumeState, ...data });
  };
  const prevStep = function () {
    setStep((prevStep) => prevStep - 1);
  };

  const nextStep = function () {
    setStep((prevStep) => prevStep + 1);
  };

  // useEffect(() => {
  //   console.log(step);
  // }, [step]);

  const renderSwitch = (param) => {
    switch (param) {
      case 1:
        return (
          <PersonalDetails
            nextStep={nextStep}
            resumeState={resumeState}
            saveData={saveData}
          />
        );
      case 2:
        return (
          <Education
            nextStep={nextStep}
            prevStep={prevStep}
            resumeState={resumeState}
            saveData={saveData}
          />
        );
      case 3:
        return (
          <Projects
            nextStep={nextStep}
            prevStep={prevStep}
            resumeState={resumeState}
            saveData={saveData}
          />
        );
      case 4:
        return (
          <Experience
            nextStep={nextStep}
            prevStep={prevStep}
            resumeState={resumeState}
            saveData={saveData}
          />
        );
      case 5:
        return (
          <AdditionalDetails
            nextStep={nextStep}
            prevStep={prevStep}
            resumeState={resumeState}
            saveData={saveData}
            setResumeState={setResumeState}
          />
        );
      default:
        prevStep();
    }
  };
  return <>{renderSwitch(step)}</>;
};
export default Resume;
