// import { useResumeContext } from "../../context/resume-context";
import { useForm } from "react-hook-form";
import { Grid, Button } from "@mui/material";
import displayGridItems from "../UI/GridItem";
import { School, Interests, Download } from "@mui/icons-material/";

const AdditionalDetails = ({ prevStep, nextStep, resumeState, saveData }) => {
  // const [resumeContext, setResumeContext] = useResumeContext();
  const { handleSubmit, register } = useForm();

  // const saveData = (data) => {
  //   setResumeContext({ ...resumeContext, ...data });
  // };

  const goBack = (e) => {
    e.preventDefault();
    handleSubmit(saveData)(e);
    prevStep();
  };

  const goNext = (e) => {
    e.preventDefault();
    handleSubmit(saveData)(e);
    nextStep();
  };

  const textFieldItemsRow1 = [
    { label: "Skill 1", id: "skill1", icon: <School /> },
    { label: "Skill 2", id: "skill2", icon: <School /> },
    { label: "Skill 3", id: "skill3", icon: <School /> },
    { label: "Skill 4", id: "skill4", icon: <School /> },
    { label: "Skill 5", id: "skill5", icon: <School /> },
    { label: "Skill 6", id: "skill6", icon: <School /> },
  ];

  const textFieldItemsRow2 = [
    { label: "Interest 1", id: "interest1", icon: <Interests /> },
    { label: "Interest 2", id: "interest2", icon: <Interests /> },
    { label: "Interest 3", id: "interest3", icon: <Interests /> },
    { label: "Interest 4", id: "interest4", icon: <Interests /> },
    { label: "Interest 5", id: "interest5", icon: <Interests /> },
    { label: "Interest 6", id: "interest6", icon: <Interests /> },
  ];

  const style = {
    backgroundColor: "#2f91ff",
    position: "relative",
    justifyContent: "center",
    alignItems: "center",
    padding: "0 5px",
    minWidth: "120px",
    height: "45px",
    fontFamily: "Raleway-Bold",
    fontSize: "16px",
    color: "#fff",
    lineHeight: 1.2,
    textTransform: "uppercase",
    border: "none",
  };

  const createLocalPDF = function (blob) {
    var url = window.URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    a.download = "Resume.pdf";
    document.body.append(a);
    console.log("Creating local PDF", new Date().toJSON("hh:mm:ss.ms"));
    a.click();
    a.remove();
  };

  const create_get_pdf = async function () {
    const url = "/create-pdf";
    // console.log("Here's the forms data:", resumeContext);
    try {
      console.log("inside submitHandler", new Date().toJSON("hh:mm:ss.ms"));
      await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ resume: resumeState }),
      });
      console.log("Getting PDF", new Date().toJSON("hh:mm:ss.ms"));
      setTimeout(() => {
        fetch("/get-pdf", {
          method: "GET",
          headers: {
            "Content-Type": "application/pdf",
          },
        })
          .then((res) => res.blob())
          .then((blob) => {
            // console.log(blob);
            createLocalPDF(blob);
          });
      }, 3000);
    } catch (err) {
      console.log(err);
    }
  };

  const submitFormHandler = async (e) => {
    e.preventDefault();
    handleSubmit(saveData)(e);
    setTimeout(create_get_pdf, 20000);
  };

  const ListOfButtons = () => {
    return (
      <div className="btn-outer">
        <button className="resume-form-btn btn-left" onClick={goBack}>
          &lt; Previous
        </button>
        <Button
          variant="contained"
          style={style}
          onClick={submitFormHandler}
          endIcon={<Download />}
        >
          Download Resume
        </Button>
        <button
          className="resume-form-btn btn-right"
          onClick={submitFormHandler}
        >
          Download
        </button>

        <button className="resume-form-btn btn-right" disabled onClick={goNext}>
          Next &gt;
        </button>
      </div>
    );
  };

  return (
    <div className="resumeContainer additionalDetailsForm">
      <span className="resumeContainer-headline">Additional Details</span>
      <div className="resumeContainer-form1">
        <Grid container spacing={1.5}>
          <span className="resumeContainer-headline2">Skills/Languages</span>
          {displayGridItems(4, textFieldItemsRow1, resumeState, register)}
        </Grid>
        <Grid container spacing={1.5}>
          <span
            className="resumeContainer-headline2"
            style={{ paddingTop: "25px" }}
          >
            Interests
          </span>
          {displayGridItems(4, textFieldItemsRow2, resumeState, register)}
        </Grid>
        {ListOfButtons()}
      </div>
    </div>
  );
};

export default AdditionalDetails;
