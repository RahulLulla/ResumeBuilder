import { useResumeContext } from "../../context/resume-context";
import { useForm } from "react-hook-form";
import { Grid } from "@mui/material";
import displayGridItems from "../UI/GridItem";
import { Title, Link, Description } from "@mui/icons-material/";

const Projects = ({ prevStep, nextStep }) => {
  const [resumeContext, setResumeContext] = useResumeContext();
  const { handleSubmit, register } = useForm();

  const saveData = (data) => {
    setResumeContext({ ...resumeContext, ...data });
  };

  const goBack = (e) => {
    e.preventDefault();
    handleSubmit(saveData)(e);
    prevStep();
  };

  const goNext = (e) => {
    e.preventDefault();
    handleSubmit(saveData)(e);
    nextStep();
  };

  const textFieldItemsCol1 = [
    { label: "Title", id: "projectTitle1", icon: <Title /> },
    { label: "Link", id: "projectLink1", icon: <Link /> },
    { label: "Description", id: "projectDesc1", icon: <Description /> },
  ];

  const textFieldItemsCol2 = [
    { label: "Title", id: "projectTitle2", icon: <Title /> },
    { label: "Link", id: "projectLink2", icon: <Link /> },
    { label: "Description", id: "projectDesc2", icon: <Description /> },
  ];

  return (
    <div className="resumeContainer projectForm">
      <span className="resumeContainer-headline">Projects</span>
      <div className="resumeContainer-form1">
        <Grid container spacing={1.5}>
          <span className="resumeContainer-headline2">Project 1</span>
          {displayGridItems(12, textFieldItemsCol1, resumeContext, register)}
        </Grid>
        <Grid container spacing={1.5}>
          <span
            className="resumeContainer-headline2"
            style={{ paddingTop: "25px" }}
          >
            Project 2
          </span>
          {displayGridItems(12, textFieldItemsCol2, resumeContext, register)}
        </Grid>
        <div className="btn-outer">
          <button className="resume-form-btn btn-left" onClick={goBack}>
            &lt; Previous
          </button>
          <button className="resume-form-btn btn-right" onClick={goNext}>
            Next &gt;
          </button>
        </div>
      </div>
    </div>
  );
};

export default Projects;
