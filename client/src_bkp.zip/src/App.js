import React from "react";
import Resume from "./components/Pages/Resume";
import { ResumeProvider } from "./context/resume-context";

function App() {
  return (
    <React.Fragment>
      <ResumeProvider>
        <Resume />
      </ResumeProvider>
    </React.Fragment>
  );
}

export default App;
