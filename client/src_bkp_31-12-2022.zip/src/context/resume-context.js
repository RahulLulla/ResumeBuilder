import React, { createContext, useState, useContext } from "react";

export const ResumeContext = createContext();

export function ResumeProvider({ children }) {
  const personalDetails = {
    firstName: "",
    lastName: "",
    email: "",
    phoneNumber: "",
    website: "",
    github: "",
    linkedIn: "",
    twitter: "",
    state: "",
    city: "",
  };

  const educationDetails = {
    college: "",
    collegeStart: "",
    collegeEnd: "",
    collegeQual: "",
    collegeDesc: "",
    school: "",
    schoolStart: "",
    schoolEnd: "",
    schoolQual: "",
    schoolDesc: "",
  };

  const projectDetails = {
    projectTitle1: "",
    projectLink1: "",
    projectDesc1: "",
    projectTitle2: "",
    projectLink2: "",
    projectDesc2: "",
  };

  const experienceDetails = {
    company1Exp: "",
    company1Pos: "",
    company1Duration: "",
    company1Desc: "",
    company2Exp: "",
    company2Pos: "",
    company2Duration: "",
    company2Desc: "",
  };

  const extraDetails = {
    skill1: "",
    skill2: "",
    skill3: "",
    skill4: "",
    skill5: "",
    skill6: "",
    interest1: "",
    interest2: "",
    interest3: "",
    interest4: "",
    interest5: "",
    interest6: "",
  };

  const value = useState({
    ...personalDetails,
    ...educationDetails,
    ...projectDetails,
    ...experienceDetails,
    ...extraDetails,
  });

  return (
    <ResumeContext.Provider value={value}>{children}</ResumeContext.Provider>
  );
}

export function useResumeContext() {
  const context = useContext(ResumeContext);
  // console.log(context);
  if (!context)
    throw new Error("useResumeContext must be used within the ResumeProvider");
  return context;
}
