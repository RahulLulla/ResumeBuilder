import { React } from "react";
import { useResumeContext } from "../../context/resume-context";
import { useForm } from "react-hook-form";
import { Grid } from "@mui/material";

import displayGridItems from "../UI/GridItem";

import {
  School,
  // CalendarToday,
  DateRange,
  Description,
} from "@mui/icons-material/";

const Education = ({ prevStep, nextStep, saveData }) => {
  const [resumeContext] = useResumeContext();
  const {
    handleSubmit,
    register,
    // watch,
    // formState: { errors },
  } = useForm();

  const goBack = (e) => {
    e.preventDefault();
    handleSubmit(saveData)(e);
    prevStep();
  };

  const goNext = (e) => {
    e.preventDefault();
    handleSubmit(saveData)(e);
    nextStep();
  };

  const textFieldItemsRow1 = [
    { label: "College/University", id: "college", icon: <School /> },
    {
      label: "Start Year",
      id: "collegeStart",
      icon: (
        <>
          {/* <CalendarToday /> */}
          <DateRange />
        </>
      ),
    },
    {
      label: "End Year",
      id: "collegeEnd",
      icon: (
        <>
          {/* <CalendarToday /> */}
          <DateRange />
        </>
      ),
    },
    { label: "Qualification", id: "collegeQual", icon: "" },
  ];

  const textFieldItemsRow2 = [
    { label: "Description", id: "collegeDesc", icon: <Description /> },
  ];

  const textFieldItemsRow3 = [
    { label: "School", id: "school", icon: <School /> },
    {
      label: "Start Year",
      id: "schoolStart",
      icon: (
        <>
          {/* <CalendarToday /> */}
          <DateRange />
        </>
      ),
    },
    {
      label: "End Year",
      id: "schoolEnd",
      icon: (
        <>
          {/* <CalendarToday /> */}
          <DateRange />
        </>
      ),
    },
    { label: "Qualification", id: "schoolQual", icon: "" },
  ];

  const textFieldItemsRow4 = [
    { label: "Description", id: "schoolDesc", icon: <Description /> },
  ];

  return (
    // <div className="resumeContainer">
    //   <span className="resumeContainer-headline">Education Details</span>
    //   <div className="btn-outer">
    //     <button className="resume-form-btn btn-left" onClick={goBack}>
    //       &lt; Previous
    //     </button>
    //     <button className="resume-form-btn btn-right" onClick={goNext}>
    //       Next &gt;
    //     </button>
    //   </div>
    // </div>
    <div className="resumeContainer eduForm">
      <span className="resumeContainer-headline">Education Details</span>
      <div className="resumeContainer-form1">
        <Grid container spacing={1.5}>
          {displayGridItems(4, textFieldItemsRow1, resumeContext, register)}
          {displayGridItems(8, textFieldItemsRow2, resumeContext, register)}
        </Grid>
        <span
          className="resumeContainer-headline2"
          style={{ paddingTop: "10px" }}
        ></span>
        <Grid container spacing={1.5}>
          {displayGridItems(4, textFieldItemsRow3, resumeContext, register)}
          {displayGridItems(8, textFieldItemsRow4, resumeContext, register)}
        </Grid>
        <div className="btn-outer">
          <button className="resume-form-btn btn-left" onClick={goBack}>
            &lt; Previous
          </button>
          <button className="resume-form-btn btn-right" onClick={goNext}>
            Next &gt;
          </button>
        </div>
      </div>
    </div>
  );
};
export default Education;
