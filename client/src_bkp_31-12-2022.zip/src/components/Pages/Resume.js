import { useResumeContext } from "../../context/resume-context";
import { React, useRef, useState } from "react";
import Education from "./Education";
import Experience from "./Experience";
import AdditionalDetails from "./AdditionalDetails";
import PersonalDetails from "./PersonalDetails";
import Projects from "./Projects";
import FormPreview from "./FormPreview";
// import Card from "../UI/Card";

const Resume = (props) => {
  const [step, setStep] = useState(1);
  const [resumeContext, setResumeContext] = useResumeContext();
  const allRefs = useRef();

  const allFields = [
    { firstName: "", key: 1 },
    { lastName: "", key: 2 },
    { email: "", key: 3 },
    { phoneNumber: "", key: 4 },
    { website: "", key: 5 },
    { github: "", key: 6 },
    { linkedIn: "", key: 7 },
    { twitter: "", key: 8 },
    { state: "", key: 9 },
    { city: "", key: 10 },
    { college: "", key: 11 },
    { collegeStart: "", key: 12 },
    { collegeEnd: "", key: 13 },
    { collegeQual: "", key: 14 },
    { collegeDesc: "", key: 15 },
    { school: "", key: 16 },
    { schoolStart: "", key: 17 },
    { schoolEnd: "", key: 18 },
    { schoolQual: "", key: 19 },
    { schoolDesc: "", key: 20 },
    { projectTitle1: "", key: 21 },
    { projectLink1: "", key: 22 },
    { projectDesc1: "", key: 23 },
    { projectTitle2: "", key: 24 },
    { projectLink2: "", key: 25 },
    { projectDesc2: "", key: 26 },
    { company1Exp: "", key: 27 },
    { company1Pos: "", key: 28 },
    { company1Duration: "", key: 29 },
    { company1Desc: "", key: 30 },
    { company2Exp: "", key: 31 },
    { company2Pos: "", key: 32 },
    { company2Duration: "", key: 33 },
    { company2Desc: "", key: 34 },
    { skill1: "", key: 35 },
    { skill2: "", key: 36 },
    { skill3: "", key: 37 },
    { skill4: "", key: 38 },
    { skill5: "", key: 39 },
    { skill6: "", key: 40 },
    { interest1: "", key: 41 },
    { interest2: "", key: 42 },
    { interest3: "", key: 43 },
    { interest4: "", key: 44 },
    { interest5: "", key: 45 },
    { interest6: "", key: 46 },
  ];

  const saveData = (data) => {
    setResumeContext((prevResumeContext) => ({
      ...prevResumeContext,
      ...data,
    }));
  };
  const prevStep = function () {
    setStep((prevStep) => prevStep - 1);
  };

  const nextStep = function () {
    setStep((prevStep) => prevStep + 1);
  };

  // useEffect(() => {
  //   console.log(step);
  // }, [step]);

  const renderSwitch = (param) => {
    switch (param) {
      case 1:
        return (
          <PersonalDetails
            nextStep={nextStep}
            // resumeContext={resumeContext}
            saveData={saveData}
            allRefs={allRefs}
            // Fields={allFields.slice(0, 9)}
          />
        );
      case 2:
        return (
          <Education
            nextStep={nextStep}
            prevStep={prevStep}
            saveData={saveData}
          />
        );
      case 3:
        return (
          <Projects
            nextStep={nextStep}
            prevStep={prevStep}
            saveData={saveData}
          />
        );
      case 4:
        return (
          <Experience
            nextStep={nextStep}
            prevStep={prevStep}
            saveData={saveData}
          />
        );
      case 5:
        return (
          <AdditionalDetails
            nextStep={nextStep}
            prevStep={prevStep}
            saveData={saveData}
            // allRefs={allRefs}
            // Fields={allFields.slice(10, 21)}
          />
        );
      case 6:
        return <FormPreview prevStep={prevStep} />;
      default:
        prevStep();
    }
  };
  return <>{renderSwitch(step)}</>;
};
export default Resume;
