import { useResumeContext } from "../../context/resume-context";
// import { useForm } from "react-hook-form";
// import { useEffect } from "react";

const FormPreview = ({ prevStep }) => {
  const [resumeContext] = useResumeContext();

  const goBack = (e) => {
    e.preventDefault();
    prevStep();
  };

  //   var displayUI = () => {
  //     return <p>Data Loading...</p>;
  //   };

  //   useEffect(() => {
  //     displayUI = <p>{resumeContext}</p>;
  //   }, [resumeContext]);
  return (
    <div className="resumeContainer additionalDetailsForm">
      <span className="resumeContainer-headline">Preview</span>
      <div className="resumeContainer-form1">
        {JSON.stringify(resumeContext, null, "\n")}
        <div className="btn-outer">
          <button className="resume-form-btn btn-left" onClick={goBack}>
            &lt; Previous
          </button>
        </div>
      </div>
    </div>
  );
};
export default FormPreview;
