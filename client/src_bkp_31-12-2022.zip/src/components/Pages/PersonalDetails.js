import { useResumeContext } from "../../context/resume-context";
import { useForm } from "react-hook-form";
import { Grid } from "@mui/material";
import {
  LinkedIn,
  GitHub,
  Email,
  Language as Website,
  Call as PhoneNumber,
  Twitter,
  LocationCity as City,
} from "@mui/icons-material/";
import displayGridItems from "../UI/GridItem";
import "./PersonalDetails.css";
// import { useState } from "react";

const PersonalDetails = ({ nextStep, saveData, allRefs }) => {
  const [resumeContext] = useResumeContext();

  const { handleSubmit, register } = useForm();

  const goNext = (e) => {
    e.preventDefault();
    handleSubmit(saveData)(e);
    nextStep();
    // console.log(resumeContext);
  };

  const textFieldItemsCol1 = [
    { label: "First Name", id: "firstName" },
    { label: "Last Name", id: "lastName" },
    { label: "Email", id: "email", icon: <Email /> },
    { label: "Your website", id: "website", icon: <Website /> },
  ];

  const textFieldItemsCol2 = [
    { label: "LinkedIn", id: "linkedIn", icon: <LinkedIn /> },
    { label: "Phone Number", id: "phoneNumber", icon: <PhoneNumber /> },
    { label: "Github", id: "github", icon: <GitHub /> },
    { label: "Twitter", id: "twitter", icon: <Twitter /> },
  ];

  const textFieldItemsCol3 = [
    { label: "City", id: "city", icon: <City /> },
    { label: "State", id: "state", icon: <City /> },
  ];

  return (
    <div className="resumeContainer personalDetailsForm">
      {/* <CustomCard> */}
      <span className="resumeContainer-headline">Personal Details</span>
      <div className="resumeContainer-form1">
        <Grid
          // key="personalDetailsForm"
          container
          spacing={1.5}
        >
          {displayGridItems(
            6,
            textFieldItemsCol1,
            resumeContext,
            register,
            allRefs
          )}
          {displayGridItems(
            6,
            textFieldItemsCol2,
            resumeContext,
            register,
            allRefs
          )}
          {displayGridItems(
            6,
            textFieldItemsCol3,
            resumeContext,
            register,
            allRefs
          )}
        </Grid>
        <div className="btn-outer">
          <button
            disabled
            className="resume-form-btn btn-left"
            onClick={goNext}
          >
            &lt; Previous
          </button>
          <button className="resume-form-btn btn-right" onClick={goNext}>
            Next &gt;
          </button>
        </div>
      </div>
    </div>
  );
};

export default PersonalDetails;
