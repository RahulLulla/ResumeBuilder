// import { useResumeContext } from "../../context/resume-context";
import createLocalPDF from "./createLocalPDF";

const createAndGetPDF = async function (resumeContext) {
  // const [resumeContext] = useResumeContext();
  const url = "/create-pdf";
  console.log("Here's the forms data:", resumeContext);
  try {
    console.log("inside submitHandler", new Date().toJSON("hh:mm:ss.ms"));
    await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ resume: resumeContext }),
    });
    console.log("Getting PDF", new Date().toJSON("hh:mm:ss.ms"));
    setTimeout(() => {
      fetch("/get-pdf", {
        method: "GET",
        headers: {
          "Content-Type": "application/pdf",
        },
      })
        .then((res) => res.blob())
        .then((blob) => {
          // console.log(blob);
          createLocalPDF(blob);
        });
    }, 3000);
  } catch (err) {
    console.log(err);
  }
};

export default createAndGetPDF;
