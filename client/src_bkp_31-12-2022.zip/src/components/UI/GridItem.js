import { Grid } from "@mui/material";
import TextField from "@mui/material/TextField";
import InputAdornment from "@mui/material/InputAdornment";

const displayGridItems = (
  width,
  listOfTextFieldItems,
  resumeContext,
  register
) => {
  return (
    <>
      {listOfTextFieldItems.map((item) => {
        const stylingObj = {
          width: item.id !== "" ? "100%" : "215%",
          background: "#f2f2f2",
          borderRadius: "2px",
          fontFamily: "Raleway-SemiBold",
          marginTop: "5px",
          input: {
            fontFamily: "Raleway-SemiBold",
          },
        };
        const iconObj = {
          endAdornment: (
            <InputAdornment position="end">{item.icon}</InputAdornment>
          ),
        };
        return (
          <Grid key={item.id} item xs={width}>
            <TextField
              label={item.label}
              id={item.id}
              defaultValue={resumeContext[item.id]}
              variant="filled"
              {...register(item.id)}
              sx={stylingObj}
              InputProps={iconObj}
            />
          </Grid>
        );
      })}
    </>
  );
};

export default displayGridItems;
