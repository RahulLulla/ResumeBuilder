import { React, useEffect, useState } from "react";
import {
  personalDetails,
  educationDetails,
  projectDetails,
  experienceDetails,
  extraDetails,
} from "../methods/stateNames";
import { renderSwitch } from "../methods/renderSwitch";

const Resume = () => {
  const [step, setStep] = useState(1);
  const [resumeData, setResumeData] = useState({
    ...personalDetails,
    ...educationDetails,
    ...projectDetails,
    ...experienceDetails,
    ...extraDetails,
  });

  useEffect(() => {
    // console.log(resumeData);
  }, [resumeData]);

  function handleChange(e) {
    setResumeData((previousState) => ({
      ...previousState,
      [e.target.name]: e.target.value,
    }));
  }

  const goBack = function (e) {
    e.preventDefault();
    setStep((prevStep) => prevStep - 1);
  };

  const goNext = function (e) {
    e.preventDefault();
    setStep((prevStep) => prevStep + 1);
  };

  return <>{renderSwitch(step, resumeData, handleChange, goNext, goBack)}</>;
};
export default Resume;
