import { React } from "react";
import { Grid } from "@mui/material";
import { listOfButtons } from "../methods/listOfButtons";

import displayGridItemsUsingState from "../methods/displayGridItemsUsingState";

import {
  School,
  // CalendarToday,
  DateRange,
  Description,
} from "@mui/icons-material/";
import { useForm } from "react-hook-form";

const Education = ({ goBack, goNext, handleChange, resumeData }) => {
  const { register } = useForm();

  const textFieldItemsRow1 = [
    { label: "College/University", id: "college", icon: <School /> },
    {
      label: "Start Year",
      id: "collegeStart",
      icon: (
        <>
          {/* <CalendarToday /> */}
          <DateRange />
        </>
      ),
    },
    {
      label: "End Year",
      id: "collegeEnd",
      icon: (
        <>
          {/* <CalendarToday /> */}
          <DateRange />
        </>
      ),
    },
    { label: "Qualification", id: "collegeQual", icon: "" },
  ];

  const textFieldItemsRow2 = [
    { label: "Description", id: "collegeDesc", icon: <Description /> },
  ];

  const textFieldItemsRow3 = [
    { label: "School", id: "school", icon: <School /> },
    {
      label: "Start Year",
      id: "schoolStart",
      icon: (
        <>
          {/* <CalendarToday /> */}
          <DateRange />
        </>
      ),
    },
    {
      label: "End Year",
      id: "schoolEnd",
      icon: (
        <>
          {/* <CalendarToday /> */}
          <DateRange />
        </>
      ),
    },
    { label: "Qualification", id: "schoolQual", icon: "" },
  ];

  const textFieldItemsRow4 = [
    { label: "Description", id: "schoolDesc", icon: <Description /> },
  ];

  return (
    <div className="resumeContainer eduForm">
      <span className="resumeContainer-headline">Education Details</span>
      <div className="resumeContainer-form1">
        <Grid container spacing={1.5}>
          {displayGridItemsUsingState(
            4,
            textFieldItemsRow1,
            resumeData,
            register,
            handleChange
          )}
          {displayGridItemsUsingState(
            8,
            textFieldItemsRow2,
            resumeData,
            register,
            handleChange
          )}
        </Grid>
        <span
          className="resumeContainer-headline2"
          style={{ paddingTop: "10px" }}
        ></span>
        <Grid container spacing={1.5}>
          {displayGridItemsUsingState(
            4,
            textFieldItemsRow3,
            resumeData,
            register,
            handleChange
          )}
          {displayGridItemsUsingState(
            8,
            textFieldItemsRow4,
            resumeData,
            register,
            handleChange
          )}
        </Grid>

        {listOfButtons(goBack, false, goNext, false)}
      </div>
    </div>
  );
};
export default Education;
