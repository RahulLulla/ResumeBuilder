import { useForm } from "react-hook-form";
import { Grid } from "@mui/material";
import displayGridItemsUsingState from "../methods/displayGridItemsUsingState";
import { listOfButtons } from "../methods/listOfButtons";

import {
  Description,
  Timelapse,
  Business,
  EventSeat,
} from "@mui/icons-material/";

const Experience = ({ goBack, goNext, handleChange, resumeData }) => {
  const { register } = useForm();

  const textFieldItemsRol1 = [
    { label: "Institute/Organization", id: "company1Exp", icon: <Business /> },
    { label: "Position", id: "company1Pos", icon: <EventSeat /> },
    { label: "Duration", id: "company1Duration", icon: <Timelapse /> },
  ];

  const textFieldItemsRow2 = [
    { label: "Description", id: "company1Desc", icon: <Description /> },
  ];

  const textFieldItemsRow3 = [
    { label: "Institute/Organization", id: "company2Exp", icon: <Business /> },
    { label: "Position", id: "company2Pos", icon: <EventSeat /> },
    { label: "Duration", id: "company2Duration", icon: <Timelapse /> },
  ];

  const textFieldItemsRow4 = [
    { label: "Description", id: "company2Desc", icon: <Description /> },
  ];

  return (
    <div className="resumeContainer experienceForm">
      <span className="resumeContainer-headline">Experience</span>
      <div className="resumeContainer-form1">
        <Grid container spacing={1.5}>
          <span className="resumeContainer-headline2">Experience 1</span>
          {displayGridItemsUsingState(
            4,
            textFieldItemsRol1,
            resumeData,
            register,
            handleChange
          )}
          {displayGridItemsUsingState(
            12,
            textFieldItemsRow2,
            resumeData,
            register,
            handleChange
          )}
        </Grid>
        <Grid container spacing={1.5}>
          <span
            className="resumeContainer-headline2"
            style={{ paddingTop: "25px" }}
          >
            Experience 2
          </span>
          {displayGridItemsUsingState(
            4,
            textFieldItemsRow3,
            resumeData,
            register,
            handleChange
          )}
          {displayGridItemsUsingState(
            12,
            textFieldItemsRow4,
            resumeData,
            register,
            handleChange
          )}
        </Grid>
        {listOfButtons(goBack, false, goNext, false)}
      </div>
    </div>
  );
};
export default Experience;
