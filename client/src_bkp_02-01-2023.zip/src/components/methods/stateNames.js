export const personalDetails = {
  firstName: "",
  lastName: "",
  email: "",
  phoneNumber: "",
  website: "",
  github: "",
  linkedIn: "",
  twitter: "",
  state: "",
  city: "",
};

export const educationDetails = {
  college: "",
  collegeStart: "",
  collegeEnd: "",
  collegeQual: "",
  collegeDesc: "",
  school: "",
  schoolStart: "",
  schoolEnd: "",
  schoolQual: "",
  schoolDesc: "",
};

export const projectDetails = {
  projectTitle1: "",
  projectLink1: "",
  projectDesc1: "",
  projectTitle2: "",
  projectLink2: "",
  projectDesc2: "",
};

export const experienceDetails = {
  company1Exp: "",
  company1Pos: "",
  company1Duration: "",
  company1Desc: "",
  company2Exp: "",
  company2Pos: "",
  company2Duration: "",
  company2Desc: "",
};

export const extraDetails = {
  skill1: "",
  skill2: "",
  skill3: "",
  skill4: "",
  skill5: "",
  skill6: "",
  interest1: "",
  interest2: "",
  interest3: "",
  interest4: "",
  interest5: "",
  interest6: "",
};
