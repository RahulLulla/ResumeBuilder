import React from "react";
import Resume from "./components/Pages/Resume";

function App() {
  return <Resume />;
}

export default App;
