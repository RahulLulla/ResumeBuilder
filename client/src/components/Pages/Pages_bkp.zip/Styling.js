import {
  ThemeProvider,
  createMuiTheme,
  makeStyles,
} from "@material-ui/material/styles";

const theme = createMuiTheme();
const Styles = {
  card: {
    margin: "0 auto",
    borderRadius: 20,
    boxShadow: "0 2px 8px rgba(0, 0, 0, 0.26)",
    width: "30%",
    height: "60%",
    border: "2px dashed red",
    backgroundColor: "white",
  },
};
const useStyles = makeStyles(Styles);

function Styling(props) {
  return <ThemeProvider theme={theme}>{props.children}</ThemeProvider>;
}
export default Styling;
